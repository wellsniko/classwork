class Enrollment < ApplicationRecord

end
